import { Component } from '@angular/core';
import { Navbar } from '../navbar/navbar';
import { Body } from '../body/body';

@Component({
  selector: 'app-header',
  imports: [Navbar,Body],
  templateUrl: './header.html',
  styleUrl: './header.css'
})
export class Header {

}
